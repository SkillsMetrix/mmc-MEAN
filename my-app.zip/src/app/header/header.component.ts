import { Component } from "@angular/core";
import { UserService } from "../shared/services/userdata.service";
import { ProjectService } from "../shared/services/project.service";

@Component({
    selector: 'header-app',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']

})
export class Header {
    userdata
    prodata
    constructor(private us: UserService, private pr: ProjectService) {
        this.userdata = this.us.loadUsers()
        this.prodata = this.pr.loadProjects()
    }
    title = 'Welcome to header'


}