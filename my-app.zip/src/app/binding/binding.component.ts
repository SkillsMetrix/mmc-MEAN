import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  styleUrls: ['./binding.component.css']
})
export class BindingComponent {
@Input()
  uname='nitin'
profile='https://images.pexels.com/photos/1704488/pexels-photo-1704488.jpeg?auto=compress&cs=tinysrgb&w=800'

showData(){
  alert('user data shown')
}
people:any[]=[
  {
    "name":"User-1",
    "country":"USA"
  },
  {
    "name":"User-2",
    "country":"INDIA"
  },
  {
    "name":"User-3",
    "country":"UK"
  },
  {
    "name":"User-4",
    "country":"INDIA"
  },
]
getColor(country:string){
  switch(country){
      case 'UK' :
        return 'green'
        case 'USA' :
          return 'blue'
          case 'INDIA' :
            return 'purple'
            default:
              return country
  }
}
}
