import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";



@Injectable()
export class HeaderInter implements HttpInterceptor{
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const API_KEY='API123'
        const ROLE_KEY='ROLE123'
       
        return next.handle(req.clone({setHeaders:{API_KEY,ROLE_KEY}}))
        
    }
}