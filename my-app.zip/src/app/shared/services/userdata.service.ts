import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class UserService{
constructor(private http:HttpClient){}
    loadUsers():string[]{
        return ['admin','manager','QA']
    }

    addUserToDB(data:any){
        this.http.post('https://mmc-angular-default-rtdb.firebaseio.com/demo.json',data).subscribe
        ((response)=> console.log(response))
        
    }
    loadUserFromDB(){
       return this.http.get('https://mmc-angular-default-rtdb.firebaseio.co/demo.json') 
}
}