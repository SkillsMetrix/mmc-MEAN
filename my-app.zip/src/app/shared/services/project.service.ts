import { Injectable } from "@angular/core";

@Injectable()
export class ProjectService{

    loadProjects():string[]{
        return ['Pro1','Pro2','pro3']
    }
}