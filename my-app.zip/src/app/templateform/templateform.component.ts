import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/services/userdata.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent implements OnInit {

  users: any[] = []
  ngOnInit(): void {
    console.log('inside init');


  }
  constructor(private us: UserService) {
    console.log('inside cons');

  }

  udata = {
    uname: 'admin'
  }

  loadUsers() {
    this.us.loadUserFromDB().subscribe((res) => {
      const myArray=[]
      for(let key in res){
        myArray.push(res[key])

      }
      this.users=myArray

    })
  }
  addUser(nf: NgForm) {
    console.log(nf.value);

    this.us.addUserToDB(nf.value)
  }
}
