import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainApp } from './mainapp/mainapp.component';
import { Header } from './header/header.component';
import { UserService } from './shared/services/userdata.service';
import { ProjectService } from './shared/services/project.service';
import { BindingComponent } from './binding/binding.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewchildComponent } from './viewchild/viewchild.component';
import { RenderComponent } from './render/render.component';
import { TemplateformComponent } from './templateform/templateform.component';
import { DatadrivenformComponent } from './datadrivenform/datadrivenform.component'
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http'
import { Logger } from './shared/interceptors/Logger.interceptor';
import { Logger2 } from './shared/interceptors/Logger2.interceptor';
import { HeaderInter } from './shared/interceptors/Header.interceptor';
import { ErrorInter } from './shared/interceptors/ErrorInter.interceptor';

@NgModule({
  // to declare all the components
  declarations: [
    AppComponent,
    MainApp,
    Header,
    BindingComponent,
    ViewchildComponent,
    RenderComponent,
    TemplateformComponent,
    DatadrivenformComponent
  ],
  // only for module
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  // only for services
  providers: [UserService,ProjectService,
    {provide:HTTP_INTERCEPTORS,useClass:Logger,multi:true},
   {provide:HTTP_INTERCEPTORS,useClass:Logger2,multi:true},
    {provide:HTTP_INTERCEPTORS,useClass:HeaderInter,multi:true},
    {provide:HTTP_INTERCEPTORS,useClass:ErrorInter,multi:true}
  
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
