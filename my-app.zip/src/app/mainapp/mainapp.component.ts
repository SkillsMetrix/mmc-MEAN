import { Component, ViewChild } from "@angular/core";
import { ViewchildComponent } from "../viewchild/viewchild.component";

@Component({
    selector:'main-app',
    templateUrl:'./mainapp.component.html',
    styleUrls:['./mainapp.component.css']

})
export class MainApp {
newname='shyam'
@ViewChild(ViewchildComponent)
private vc={} as ViewchildComponent

inc(){
    this.vc.increment()
}
dec(){
    this.vc.decrement()
}
}