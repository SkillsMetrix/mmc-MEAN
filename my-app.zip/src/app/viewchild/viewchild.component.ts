import { Component } from '@angular/core';

@Component({
  selector: 'app-viewchild',
  templateUrl: './viewchild.component.html',
  styleUrls: ['./viewchild.component.css']
})
export class ViewchildComponent {

  message:string=''
  count:number=0

  increment(){
    this.count=this.count+1
    this.message="Counter  "+ this.count
  }
  decrement(){
    this.count=this.count-1
    this.message="Counter  "+ this.count
  }
}
