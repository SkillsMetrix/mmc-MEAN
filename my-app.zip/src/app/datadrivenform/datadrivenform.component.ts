import { formatCurrency } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../shared/services/userdata.service';

@Component({
  selector: 'app-datadrivenform',
  templateUrl: './datadrivenform.component.html',
  styleUrls: ['./datadrivenform.component.css']
})
export class DatadrivenformComponent {


  myForm: FormGroup
  uname: FormControl
  pass: FormControl
  email: FormControl
  city: FormControl

  createFormControls() {
    this.uname = new FormControl('', Validators.required)
    this.pass = new FormControl('', [Validators.required, Validators.minLength(6)])
    this.email = new FormControl('', [Validators.required, Validators.email,this.emailDomainValidator])
    this.city = new FormControl('')
  }
  createForm() {
    this.myForm = new FormGroup({
      uname: this.uname,
      pass: this.pass,
      email: this.email,
      city: this.city
    })
  }
  constructor(private us: UserService) {
    this.createFormControls()
    this.createForm()
  }

  emailDomainValidator(control: FormControl) {
    let email = control.value
    if (email && email.indexOf("@") != -1) {
      let [_, domain] = email.split('@')
      if (domain !== 'mmc.com') {
        return {
          emailDomain: {
            mydomain: domain
          }
        }
      }

    }
    return null
  }
  addUser() {

    this.us.addUserToDB(this.myForm.value)

  }
}
